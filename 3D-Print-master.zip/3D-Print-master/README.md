# 3D-Print

This is a Github page for my 3D print. It did not turn out as expected. 



The goal was to create a rasied component that would amount to a Braille surface communicating the Orion constellation.

There was an error in my design phase and it resulted in the object portrayed in the images below. 

![alt text](https://github.com/ladkins19/3D-Print/blob/master/IMG_0884.jpeg?raw=true)


![alt text](https://github.com/ladkins19/3D-Print/blob/master/IMG_0883.jpeg?raw=true)
